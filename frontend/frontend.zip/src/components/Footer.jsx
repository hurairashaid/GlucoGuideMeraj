import React from "react";

const Footer = () => {
  return (
    <>
      <footer className=" text-center text-lg-start">
        {/* <!-- Copyright --> */}

        {/* <!-- Copyright --> */}
      </footer>
    </>
  );
};

export default Footer;
